package empresa.com;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class dibujando extends View{
    
        Paint pincel = new Paint();
        Paint otro = new Paint();
        public dibujando(Context contexto)
        {
        	super(contexto);
        	pincel.setColor(Color.RED);
        	otro.setColor(Color.BLACK);
        }
        
    @Override
    public void onDraw(Canvas areadibujo)
    {
    	areadibujo.drawCircle(200, 300, 100, pincel);
    	areadibujo.drawCircle(30, 30, 10, otro);
   	}
}
