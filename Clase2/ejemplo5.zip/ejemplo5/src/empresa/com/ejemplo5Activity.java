package empresa.com;

import android.app.Activity;
import android.os.Bundle;

public class ejemplo5Activity extends Activity {
    /** Called when the activity is first created. */
	
	dibujando dibujo;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);
        
        dibujo = new dibujando(this);
        setContentView(dibujo);
    }
}