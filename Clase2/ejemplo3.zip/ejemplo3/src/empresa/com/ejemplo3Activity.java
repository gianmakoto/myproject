package empresa.com;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
//import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.view.View.OnClickListener;

public class ejemplo3Activity extends Activity {
    /** Called when the activity is first created. */
    
	ImageButton bImagen;
	ImageButton bDetalle;
	ImageButton bMenu;
	AlertDialog ventanita;	
	android.content.DialogInterface.OnClickListener ventanitaCerrar;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initComponent();
    }
    
    public void initComponent()
    {
    	bImagen = (ImageButton)findViewById(R.id.btnImagen);
    	bDetalle = (ImageButton)findViewById(R.id.btnDetalle);
    	bMenu = (ImageButton)findViewById(R.id.btnMenu);
    	bImagen.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mostrar();
			}
    	});
    	
    	bDetalle.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mostrarDetalle();
			}
    	});
    	
    	bMenu.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				mostrarMenu();
			}
    	});
    	
    }
    
   public void mostrar()
   { 
	     ventanita = new AlertDialog.Builder(this).create();
         ventanita.setTitle("Mensaje");
	     ventanita.setMessage("Acaba de cambiar de papel tapiz");
	     ventanita.setButton("Cerrar", ventanitaCerrar);
	     ventanita.show();    
   }
    
   public void mostrarDetalle()
   {
	  // setContentView(R.layout.detallectivity);
	Intent i = new Intent(this,DetalleActivity.class);
	this.startActivity(i);
   }
   
   public void mostrarMenu()
   {
	  // setContentView(R.layout.detallectivity);
	Intent i = new Intent(this,selecciondestinos.class);
	this.startActivity(i);
   }
   
   
	public void ventanitaCerrar(){}
}