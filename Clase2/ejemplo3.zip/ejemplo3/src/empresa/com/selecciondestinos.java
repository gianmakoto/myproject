package empresa.com;
import android.R.integer;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
	
public class selecciondestinos extends Activity {
	
	
	    ImageButton ibImg1,ibImg2,ibImg3;
	    TextView texto;
	    int posicion;
	    ImageView _visor;
	   private Integer[] galeria = {
	        		R.drawable.bleach,
	        		R.drawable.naruto,
	        		R.drawable.ulquiorra
	        		};
	   	   
	    	private String[] Nombres= {
	    			"bleach","naruto","ulquiorra"
	    	};   
	    	
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.menuopciones);
	        
	        posicion = 0;
	        _visor = (ImageView)findViewById(R.id.imageView1);
	        _visor.setImageResource(galeria[posicion]);
	        Button bRetroceder= (Button)findViewById(R.id.btnRetroceder);
	        Button bAvanzar = (Button)findViewById(R.id.btnAvanzar);
	        
	        texto = (TextView)findViewById(R.id.txtNombre);
	        ibImg1 = (ImageButton)findViewById(R.id.imageButton1);
	        ibImg2 = (ImageButton)findViewById(R.id.imageButton2);
	        ibImg3 = (ImageButton)findViewById(R.id.imageButton3);
	        
	        
	        ibImg1.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posicion = 0;
				    Pintar(posicion);	
				}
			});
	        
	        ibImg2.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posicion = 1;
				    Pintar(posicion);
				}
			});
	        
	        ibImg3.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posicion = 2;
				    Pintar(posicion);	
				}
			});
	        

	        bAvanzar.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posicion++;
					 if(posicion == 3)
						 posicion = 0;
					 
					 _visor.setImageResource(galeria[posicion]);
					 texto.setText(Nombres[posicion]);
					
				}
			});
	        
	        bRetroceder.setOnClickListener(new OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
					posicion--;
					 if(posicion == -1)
						 posicion = 2;
					 
					 _visor.setImageResource(galeria[posicion]);
					 texto.setText(Nombres[posicion]);
				}
			});
	        
	        
	    }
	    
	    public void Pintar(int i)
	    {
	    	_visor.setImageResource(galeria[i]);
	    	texto.setText(Nombres[i]);
	    }
	    

	
	
}
